const Inputs = (props) => {
  return <input {...props} />;
};
export default Inputs;
